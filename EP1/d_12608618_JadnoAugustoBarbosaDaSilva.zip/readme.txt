Execução:
./polinomio entrada.txt saida.txt

Compilação:
gcc -lm polinomio.c -o polinomio

O uso da opcao -lm é necessário por causa da biblioteca math.h
